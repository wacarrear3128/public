package com.example.demo.entity.dao;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.entity.models.*;

public interface IBicicletaDao extends CrudRepository<Bicicleta,Long>{

}
