package com.example.demo.entity.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.dao.IBicicletaDao;
import com.example.demo.entity.models.Bicicleta;

@Service
public class BicicletaServiceImpl implements IBicicletaService {
	@Autowired 
	private IBicicletaDao bibicletaDao ;
	
	@Override
	public Bicicleta get(long id) {
		// TODO Auto-generated method stub
		return bibicletaDao.findById(id).get();}

	@Override
	public List<Bicicleta> getAll() {
		// TODO Auto-generated method stub
		return (List<Bicicleta>) bibicletaDao.findAll();}

	@Override
	public void post(Bicicleta bicicleta) {
		bibicletaDao.save(bicicleta);}

	@Override
	public void delete(long id) {
		bibicletaDao.deleteById(id);}

	@Override
	public void put(Bicicleta bicicleta, long id) {
				
		bibicletaDao.findById(id).ifPresent( (x)-> {
			bicicleta.setId(id);
			bibicletaDao.save(bicicleta);
		});}

}
