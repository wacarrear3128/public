package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaMsApplication.class, args);
	}

}
