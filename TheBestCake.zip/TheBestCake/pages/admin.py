from django.contrib import admin
from .models import Page
from import_export import resources
from import_export.admin import ImportExportModelAdmin

#Creamos el botón importar-exportar
class PagesResource(resources.ModelResource):
    class Meta:
        model = Page

# Register your models here.
class PageAdmin(ImportExportModelAdmin ,admin.ModelAdmin):
    readonly_fields=('created','updated')
    resource_class = PagesResource

admin.site.register(Page,PageAdmin)