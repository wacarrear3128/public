from django.contrib import admin
from .models import Link
from import_export import resources
from import_export.admin import ImportExportModelAdmin

#Creamos el botón importar-exportar
class  SocialResource(resources.ModelResource):
    class Meta:
        model = Link

# Register your models here.
class LinkAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    readonly_fields=('created','updated')
    resources = SocialResource

admin.site.register(Link,LinkAdmin)