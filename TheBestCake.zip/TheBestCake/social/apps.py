from django.apps import AppConfig


class SocialConfig(AppConfig):
    name = 'social'
    verbose_name="Redes sociales"