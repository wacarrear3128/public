from django.shortcuts import render

# Creamos vistas de la página web
#Función para mostrar la interfaz principal de la página web
def home(request):
    return render(request,"core/home.html")

#Función para mostrar la interfaz de Acerca de, de la página web
def about(request):
    return render(request,"core/about.html")

#Función para mostrar la interfaz de Visítanos de la página web
def store(request):
    return render(request,"core/store.html")


