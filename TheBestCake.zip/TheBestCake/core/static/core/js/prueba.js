console.log("Hola mundo");

var precio = [];
var i = 0;

console.log(precio);