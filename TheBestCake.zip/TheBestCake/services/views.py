from django.shortcuts import render
from .models import Service

# Creando vistas de servicios, para la recuperación y listado de los servicios dentro de la interfaz Servicios
def services(request):
    services=Service.objects.all()
    return render(request,"services/services.html",{'services':services})