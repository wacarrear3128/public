from django.contrib import admin
from .models import Design,Comentario, CarritoCompras, ImagenesProducto
from import_export import resources
from import_export.admin import ImportExportModelAdmin

#Creamos el botón importar-exportar
class  DesignResource(resources.ModelResource):
    class Meta:
        model = Design

#Creamos el botón importar-exportar
class  ImagenesResource(resources.ModelResource):
    class Meta:
        model = ImagenesProducto

class  ComentarioResource(resources.ModelResource):
    class Meta:
        model = Comentario

#Extendemos clase de administración
class DesignAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    readonly_fields = ('created', 'updated')
    resources = DesignResource

class ComentarioAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    readonly_fields = ('created', 'updated')
    resources = ComentarioResource

class CarritoComprasAdmin(admin.ModelAdmin):
    readonly_fields = ('created', 'updated')

class ImagenesProductoAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    resources = ImagenesResource

# Registramos modelo en el administrador
admin.site.register(ImagenesProducto, ImagenesProductoAdmin)
admin.site.register(Design, DesignAdmin)
admin.site.register(Comentario, ComentarioAdmin)
admin.site.register(CarritoCompras, CarritoComprasAdmin)

