from django.shortcuts import render
from .models import Post

# Creando vista relacionada a mostrar y listar, lo relacionado al Blog
def blog(request):
    posts=Post.objects.all()
    return render(request,"blog/blog.html",{'posts':posts})