from django.contrib import admin
from .models import Post
from import_export import resources
from import_export.admin import ImportExportModelAdmin

#Creamos el botón importar-exportar
class  BlogResource(resources.ModelResource):
    class Meta:
        model = Post

# Register your models here.
class PostAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    readonly_fields=('created','updated')
    list_display=('title','published')
    ordering=('published',)
    search_fields=('title','published')
    resource_class = BlogResource

admin.site.register(Post,PostAdmin)