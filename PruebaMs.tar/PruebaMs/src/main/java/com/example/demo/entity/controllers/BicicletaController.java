package com.example.demo.entity.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.models.Bicicleta;
import java.util.List ; 

import com.example.demo.entity.services.IBicicletaService;
@RestController
public class BicicletaController {
	
 @Autowired
 IBicicletaService bicicletaService ;
 
 @GetMapping("/bicicletas")
 public List <Bicicleta> getAllBicicletas(){
	 return bicicletaService.getAll();
 }
 

 @GetMapping("/bicicleta/{id}")
 public Bicicleta getOne(@PathVariable (value = "id") long id){
	 return bicicletaService.get(id);
 }
 
 @PostMapping("/bicicleta")
 public void add(Bicicleta bicicleta){
	  bicicletaService.post(bicicleta);
 }
 
 @PutMapping("/bicicleta")
 public void update(Bicicleta bicicleta, long id){
	  bicicletaService.put(bicicleta, id);
 }
 
}
