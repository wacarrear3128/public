package com.example.demo.entity.services;

import com.example.demo.entity.models.Bicicleta;
import java.util.List ; 

public interface IBicicletaService {
public Bicicleta get (long id);
public List <Bicicleta> getAll();
public void post (Bicicleta bicicleta) ;
public void put (Bicicleta bicicleta,long id) ;
public void delete(long id);
}
