﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Facturacion.Entidades
{
    public class ECliente
    {
        public int id_cliente { get; set; }
        public string nombre_cli { get; set; }
        public string app_cli { get; set; }
        public string apm_cli { get; set; }

    }
}
