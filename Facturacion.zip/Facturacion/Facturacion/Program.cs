﻿using Facturacion.Entidades;
using Facturacion.LogicaNegocio;
using System;
using System.Collections.Generic;

namespace Facturacion
{
    public class Program
    {
        static DetalleFacturaLN dfacturaBL = new DetalleFacturaLN();
        static void Main(string[] args)
        {
            List<EDetalleFactura> dfactura = dfacturaBL.Todos(12345678);

            foreach (var item in dfactura)
            {
                Console.WriteLine("----------------------------------------------------");
                Console.WriteLine(item.nom_prod + "\t\t" + item.prec_prod + "\t" + item.cantidad + "\t" + item.monto);
                Console.WriteLine("---------------------------------------------------- \n");
                //Console.WriteLine(item.prec_prod);
                //Console.WriteLine(item.cantidad);
                //Console.WriteLine(item.monto);
            }
        }
    }
}
