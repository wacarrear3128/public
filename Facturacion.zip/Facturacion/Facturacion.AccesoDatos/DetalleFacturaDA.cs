﻿using Facturacion.Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Facturacion.AccesoDatos
{
    public class DetalleFacturaDA : ConexionToMySQL
    {
        public List<EDetalleFactura> GetAll(int dni)
        {
            List<EDetalleFactura> facturas = new List<EDetalleFactura>();

            using (var conexion = GetConnection())
            {
                conexion.Open();

                MySqlCommand cmd = new MySqlCommand("SELECT f.ID_FCT AS FACTURA, c.ID_CLI AS DNI, CONCAT(c.NOM_CLI, ' ', c.APP_CLI, ' ', c.APM_CLI) AS CLIENTE, p.NOM_PRD PRODUCTO, "
                                                      + "p.PRC_PRD AS PRECIO, o.CANT AS CANTIDAD, o.COST AS COSTO, f.TOT_FCT AS TOTAL, f.MNT_PGD AS ABONADO, (f.TOT_FCT - f.MNT_PGD) AS CUENTA "
                                                      + "FROM tb_facturas f \n"
                                                      + "INNER JOIN tb_clientes c ON f.FK_ID_CLI = c.ID_CLI \n"
                                                      + "INNER JOIN tb_ordenes o ON f.ID_FCT = o.FK_ID_FCT \n"
                                                      + "INNER JOIN tb_productos p ON o.FK_ID_PRD = p.ID_PRD \n"
                                                      + "WHERE c.ID_CLI = @dni", conexion);
                cmd.Parameters.AddWithValue("@dni", dni);
                MySqlDataReader lector = cmd.ExecuteReader();

                while (lector.Read())
                {
                    EDetalleFactura detalleFactura = new EDetalleFactura
                    {
                        id_fac = Convert.ToInt32(lector["FACTURA"]),
                        id_cli = Convert.ToInt32(lector["DNI"]),
                        cliente = Convert.ToString(lector["CLIENTE"]),
                        nom_prod = Convert.ToString(lector["PRODUCTO"]),
                        prec_prod = Convert.ToDouble(lector["PRECIO"]),
                        cantidad = Convert.ToDouble(lector["CANTIDAD"]),
                        monto = Convert.ToDouble(lector["COSTO"]),
                        total = Convert.ToDouble(lector["TOTAL"]),
                        abonado = Convert.ToDouble(lector["ABONADO"]),
                        cuenta = Convert.ToDouble(lector["CUENTA"])
                    };

                    facturas.Add(detalleFactura);
                }
            }
            return facturas;
        }
    }
}
